# api/app.py

from fastapi import FastAPI, Request
import boto3
import os

app = FastAPI()
runtime = boto3.client('sagemaker-runtime')

@app.post("/predict")
async def predict(request: Request):
    body = await request.body()
    response = runtime.invoke_endpoint(
        EndpointName="your-endpoint-name",
        ContentType="text/csv",
        Body=body
    )
    result = response['Body'].read().decode()
    return {"prediction": result}

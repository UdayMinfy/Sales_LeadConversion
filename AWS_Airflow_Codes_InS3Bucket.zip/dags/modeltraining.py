from airflow import DAG
from airflow.operators.python import PythonVirtualenvOperator
from datetime import datetime
import tempfile
import boto3

default_args = {
    'owner': 'uday',
    'start_date': datetime(2024, 1, 1),
    'retries': 0,
}

def train_model():
    import pandas as pd
    import boto3
    import tempfile
    import os
    from sklearn.model_selection import train_test_split
    import joblib

    # S3 settings
    bucket = 'leadscoringdb'
    key_csv = 'loadeddf_fromredshift.csv'
    key_experiment = 'scripts/experiment.py'
    key_preprocessing = 'scripts/preprocessing.py'
    target_column = 'converted'

    s3 = boto3.client('s3')

    # Download CSV
    with tempfile.NamedTemporaryFile(suffix='.csv', delete=False) as temp_csv:
        s3.download_fileobj(bucket, key_csv, temp_csv)
        csv_path = temp_csv.name

    df = pd.read_csv(csv_path)

    # --- Load and execute preprocessing.py ---
    scope = {}
    with tempfile.NamedTemporaryFile(suffix='.py', delete=False) as temp_pre:
        s3.download_fileobj(bucket, key_preprocessing, temp_pre)
        temp_pre.flush()
        with open(temp_pre.name, 'r') as f:
            exec(f.read(), scope)

    # --- Load and execute experiment.py ---
    with tempfile.NamedTemporaryFile(suffix='.py', delete=False) as temp_exp:
        s3.download_fileobj(bucket, key_experiment, temp_exp)
        temp_exp.flush()
        with open(temp_exp.name, 'r') as f:
            exec(f.read(), scope)

    # Now access your functions from scope
    get_pipeline = scope['get_full_preprocessing_pipeline']
    evaluate = scope['evaluate_classifiers']

    # --- Preprocessing and training ---
    df = df.copy()
    X = df.drop(columns=[target_column])
    y = df[target_column]
    pipeline, *_ = get_pipeline(X)
    pipeline.fit(X)
    from sklearn.model_selection import train_test_split
    X_train_raw, X_test_raw, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    #pipeline, *_ = get_pipeline(X_train_raw)
    #pipeline.fit(X_train_raw)

    X_train = pipeline.transform(X_train_raw)
    X_test = pipeline.transform(X_test_raw)

    # Train and evaluate
    evaluate(X_train, X_test, y_train, y_test, pipeline)


with DAG(
    'train_model_pipeline_from_s3',
    default_args=default_args,
    schedule_interval=None,
    catchup=False,
    description='Train model using CSV and experiment.py from S3',
) as dag:

    run_training = PythonVirtualenvOperator(
        task_id='run_training_script',
        python_callable=train_model,
        requirements=[
            "pandas", 
            "boto3", 
            "scikit-learn", 
            "joblib",
            "mlflow",
            "pyyaml",
            'xgboost'
        ],
        system_site_packages=False,
    )

    run_training

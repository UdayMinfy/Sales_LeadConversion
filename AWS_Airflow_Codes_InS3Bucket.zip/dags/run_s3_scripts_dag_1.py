from airflow import DAG
from airflow.operators.python import PythonVirtualenvOperator
from datetime import datetime
import boto3

default_args = {
    'owner': 'uday',
    'start_date': datetime(2024, 1, 1),
    'retries': 0,
}

def run_redshift_to_s3_script():
    import boto3
    import pandas as pd
    import sqlalchemy

    import os
    import tempfile

    # Download script from S3
    s3 = boto3.client('s3')
    with tempfile.NamedTemporaryFile(suffix='.py', delete=False) as temp_script:
        s3.download_fileobj('leadscoringdb', 'scripts/redshift_to_s3.py', temp_script)
        temp_script_path = temp_script.name

    # Execute the script
    with open(temp_script_path, 'r') as file:
        exec(file.read(), globals())

with DAG(
    'run_redshift_and_train_s3_scripts_new',
    default_args=default_args,
    schedule_interval=None,
    catchup=False,
    description='Download and run scripts from S3 in sequence',
) as dag:

    run_redshift_to_s3 = PythonVirtualenvOperator(
        task_id='run_redshift_to_s3',
        python_callable=run_redshift_to_s3_script,
        requirements=["pandas", "boto3", "sqlalchemy"],
        system_site_packages=False,
    )

    run_redshift_to_s3

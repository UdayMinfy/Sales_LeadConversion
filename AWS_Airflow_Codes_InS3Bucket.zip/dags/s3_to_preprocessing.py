from airflow import DAG
from airflow.operators.python import PythonVirtualenvOperator
from datetime import datetime
import boto3
import tempfile

default_args = {
    'owner': 'uday',
    'start_date': datetime(2024, 1, 1),
    'retries': 0,
}

def run_preprocessing_script():
    import boto3
    import pandas as pd
    import pickle
    import io
    import tempfile
    import os
    import sys

    BUCKET_NAME = 'leadscoringdb'
    INPUT_KEY = 'loadeddf_fromredshift.csv'
    OUTPUT_KEY = 'processed/processed_data.pkl'
    SCRIPT_KEY = 'scripts/preprocessing.py'

    # Step 1: Download preprocessing.py from S3
    s3 = boto3.client('s3')
    with tempfile.NamedTemporaryFile(suffix='.py', delete=False) as temp_script:
        s3.download_fileobj(BUCKET_NAME, SCRIPT_KEY, temp_script)
        script_path = temp_script.name

    # Step 2: Import the downloaded script dynamically
    import importlib.util
    spec = importlib.util.spec_from_file_location("preprocessing_module", script_path)
    preprocessing_module = importlib.util.module_from_spec(spec)
    sys.modules["preprocessing_module"] = preprocessing_module
    spec.loader.exec_module(preprocessing_module)

    # Step 3: Read input CSV from S3
    print(f"📥 Loading CSV from s3://{BUCKET_NAME}/{INPUT_KEY}")
    response = s3.get_object(Bucket=BUCKET_NAME, Key=INPUT_KEY)
    df = pd.read_csv(io.BytesIO(response['Body'].read()))

    # Step 4: Run pipeline
    print(f"🧪 Running preprocessing pipeline")
    pipeline, _, _, _, _ = preprocessing_module.get_full_preprocessing_pipeline(df)
    df_transformed = pipeline.fit_transform(df)

    # Step 5: Save processed output to S3
    print(f"📤 Saving processed data to s3://{BUCKET_NAME}/{OUTPUT_KEY}")
    buffer = io.BytesIO()
    pickle.dump(df_transformed, buffer)
    buffer.seek(0)
    s3.put_object(Bucket=BUCKET_NAME, Key=OUTPUT_KEY, Body=buffer)
    print("✅ Preprocessed data uploaded successfully")

with DAG(
    'run_preprocessing_pipeline_from_s3',
    default_args=default_args,
    schedule_interval=None,
    catchup=False,
    description='Run preprocessing.py from S3 and save output back to S3',
) as dag:

    run_preprocessing = PythonVirtualenvOperator(
        task_id='run_preprocessing_script',
        python_callable=run_preprocessing_script,
        requirements=["pandas", "boto3", "scikit-learn"],
        system_site_packages=False,
    )

    run_preprocessing

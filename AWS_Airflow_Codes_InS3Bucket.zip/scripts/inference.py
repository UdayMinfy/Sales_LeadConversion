# scripts/inference.py

import joblib
import numpy as np
import os

def model_fn(model_dir):
    model = joblib.load(os.path.join(model_dir, "model.joblib"))
    scaler = joblib.load(os.path.join(model_dir, "scaler.joblib"))
    return model, scaler

def input_fn(request_body, content_type="text/csv"):
    return np.array(request_body.split(",")).astype(float).reshape(1, -1)

def predict_fn(input_data, model_tuple):
    model, scaler = model_tuple
    scaled = scaler.transform(input_data)
    return model.predict(scaled)

import boto3
import pandas as pd
import time
import io  # Needed to handle in-memory file

# Set these values
workgroup_name = 'default-workgroup'
database_name = 'dev'
iam_role = 'arn:aws:iam::436749945793:role/service-role/AmazonSageMaker-ExecutionRole-20250710T140844'
query = "SELECT * FROM salesconvertion;"  # your table

# Redshift Data API client
client = boto3.client('redshift-data')

# Run the query
print(f"🔍 Executing query on workgroup: {workgroup_name}, database: {database_name}")
print(f"🔍 Query: {query}")

response = client.execute_statement(
    WorkgroupName=workgroup_name,
    Database=database_name,
    Sql=query,
    WithEvent=True
)

query_id = response['Id']
print(f"📤 Query submitted. Query ID: {query_id}")

# Wait for it to finish
status = 'STARTED'
while status in ['STARTED', 'SUBMITTED', 'PICKED']:
    status = client.describe_statement(Id=query_id)['Status']
    print(f"⏳ Query status: {status}")
    time.sleep(1)

if status == 'FINISHED':
    result = client.get_statement_result(Id=query_id)

    # Extract column names
    columns = [col['name'] for col in result['ColumnMetadata']]

    # Extract rows
    records = result['Records']
    data = []
    for record in records:
        row = [list(value.values())[0] if value else None for value in record]
        data.append(row)

    # Convert to DataFrame
    df = pd.DataFrame(data, columns=columns)
    print("✅ Query successful! Here's the data:")
    print(df.head())

    # ✅ Upload to S3 as loadeddf.csv
    s3 = boto3.client('s3')
    bucket = 'leadscoringdb'  # Replace with your bucket name
    key = 'loadeddf_fromredshift.csv'  # Replace with your desired path in S3

    csv_buffer = io.StringIO()
    df.to_csv(csv_buffer, index=False)

    s3.put_object(Bucket=bucket, Key=key, Body=csv_buffer.getvalue())
    print(f"✅ DataFrame uploaded to s3://{bucket}/{key}")

else:
    print(f"❌ Query failed with status: {status}")

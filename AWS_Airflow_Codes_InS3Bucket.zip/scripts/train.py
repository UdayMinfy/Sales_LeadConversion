# scripts/train.py

import joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
import pandas as pd
import os

X = pd.read_csv('s3://your-bucket/train_X.csv')
y = pd.read_csv('s3://your-bucket/train_y.csv')

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

clf = RandomForestClassifier()
clf.fit(X_scaled, y)

os.makedirs('/opt/ml/model', exist_ok=True)
joblib.dump(clf, '/opt/ml/model/model.joblib')
joblib.dump(scaler, '/opt/ml/model/scaler.joblib')
